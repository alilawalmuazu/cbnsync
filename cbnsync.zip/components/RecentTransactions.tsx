import React from 'react'

const RecentTransactions = () => {
  return (
    <div>RecentTransactions</div>
  )
}

export default RecentTransactions